<?php

class N2SystemApplicationTypeBackend extends N2ApplicationType {

    public $type = "backend";
}